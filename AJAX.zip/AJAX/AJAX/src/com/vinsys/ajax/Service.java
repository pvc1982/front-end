package com.vinsys.ajax;

import java.util.ArrayList;

public class Service {

	public ArrayList<Country> getCountries() {

		return new Dal().getCountries();

	}
	public ArrayList<State> getStatesByCountry(int countryId) {

		return new Dal().getStatesByCountry(countryId);

	}
	public ArrayList<City> getCitiesByState(int stateId) {

		return new Dal().getCitiesByState(stateId);

	}

}
