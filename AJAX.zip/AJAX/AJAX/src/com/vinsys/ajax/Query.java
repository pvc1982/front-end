package com.vinsys.ajax;

public interface Query {
	String SELECTCOUNTRIES = "select * from COUNTRY";
	String SELECTSTATES = "select * from STATE where countryId=?";
	String SELECTCITIES = "select * from CITY where stateId=?";

}
