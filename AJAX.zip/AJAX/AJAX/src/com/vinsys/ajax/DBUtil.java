package com.vinsys.ajax;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBUtil {
private static DataSource ds;
private static DBUtil db;
private Context context;

private DBUtil()
	{
		try {
			 context= new InitialContext();
			ds=(DataSource)context.lookup("java:/comp/env/jdbc/myDamysqlDataSource");
			System.out.println("DS got"+ds);
		} 
		
		catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

public static DataSource getDBUtil(){
	if(db==null)
		db=new DBUtil();
	return ds;
}

public static void close(Connection con){
	try {
		if(con!=null)
			con.close();
	} catch (SQLException e) {
		e.printStackTrace();
	}
}

}
