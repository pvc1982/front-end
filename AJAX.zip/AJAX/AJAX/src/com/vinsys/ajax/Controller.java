package com.vinsys.ajax;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Controller
 */
public class Controller extends HttpServlet {

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {


		RequestDispatcher rd = null;

		String country=request.getParameter("country");
		String state=request.getParameter("state");
		
		
		if(country!=null)
		{
		System.out.println("\n\nCountry :"+country);	Service service = new Service();

			request.setAttribute("states",service.getStatesByCountry(Integer.parseInt(country)));

			rd = request.getRequestDispatcher("State.jsp");
		//	rd.include(request, response);
	
		}
		
		

		
		if(state!=null)
		{
			Service service = new Service();

			request.setAttribute("cities",service.getCitiesByState(Integer.parseInt(state)));

			rd = request.getRequestDispatcher("City.jsp");
      //rd.include(request, response);
		}

		
		

		String path = request.getServletPath();
		System.out.println("Path   " + path);
		if (path.equals("/FrontController")) {
			Service service = new Service();

			request.setAttribute("countries", service.getCountries());

			rd = request.getRequestDispatcher("/Country.jsp");


		
}

		rd.forward(request, response);
}

}
