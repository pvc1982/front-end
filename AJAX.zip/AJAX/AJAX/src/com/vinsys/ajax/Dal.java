package com.vinsys.ajax;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.sql.DataSource;

public class Dal {

	DataSource ds = DBUtil.getDBUtil();

	public ArrayList<Country> getCountries() {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		ArrayList<Country> arl = new ArrayList<Country>();
		try {

			con = ds.getConnection();
			st = con.createStatement();
			rs = st.executeQuery(Query.SELECTCOUNTRIES);
			while (rs.next()) {
				Country country = new Country();

				country.setCountryId(rs.getInt(1));
				country.setCountryName(rs.getString(2));

				arl.add(country);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		finally {

			DBUtil.close(con);

		}

		return arl;
	}

	public ArrayList<State> getStatesByCountry(int countryId) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<State> arl = new ArrayList<State>();
		try {

			con = ds.getConnection();
			ps = con.prepareStatement(Query.SELECTSTATES);
			ps.setInt(1, countryId);

			rs = ps.executeQuery();
			while (rs.next()) {
				State state = new State();

				state.setStateId(rs.getInt(1));
				state.setStateName(rs.getString(2));
				arl.add(state);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		finally {

			DBUtil.close(con);

		}

		return arl;
	}

	public ArrayList<City> getCitiesByState(int stateId) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<City> arl = new ArrayList<City>();
		try {

			con = ds.getConnection();
			ps = con.prepareStatement(Query.SELECTCITIES);
			ps.setInt(1, stateId);

			rs = ps.executeQuery();
			while (rs.next()) {

				City city = new City();

				city.setCityId(rs.getInt(1));
				city.setCityName(rs.getString(2));

				arl.add(city);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		finally {

			DBUtil.close(con);

		}

		return arl;
	}

}
