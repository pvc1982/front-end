/*
database username :scott
database password :tiger
*/
drop table city;
drop table state;
drop table country;


create table country(countryId number(3) primary key,countryName varchar2(30));

create table state(stateId number(3) primary key,stateName varchar2(30),countryId number(3),
CONSTRAINT cc FOREIGN KEY(countryId) REFERENCES country(countryId));


create table city(cityId number(3) primary key,cityName varchar2(30),stateId number(3) ,
CONSTRAINT ss FOREIGN KEY(stateId) REFERENCES state(stateId));

insert into country values(101,'INDIA');
insert into country values(102,'SRILANKA');
insert into country values(103,'AMERICA');


insert into  state values(101,'MAHARASHTRA',101);
insert into  state values(102,'KARNATAKA',101);
insert into  state values(103,'ANDHRAPRADESH',101);

insert into  city values(101,'PUNE',101);
insert into  city values(102,'MUMBAI',101);
insert into  city values(103,'SHOLAPUR',101);

insert into  city values(104,'BANGLORE',102);
insert into  city values(105,'MHAISURE',102);
insert into  city values(106,'VIJAPUR',102);

insert into  city values(107,'HYDERABAD',103);
insert into  city values(108,'VIJAYWADA',103);
insert into  city values(109,'KAMAM',103);





