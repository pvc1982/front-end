
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;


/*
Author:Ch.Rajesh
Purpose: To discuss about HttpServletResponse especially  response headers
and setHeader()

*/

public class MyServlet extends HttpServlet
{
public void doGet(HttpServletRequest req,HttpServletResponse response) throws ServletException,IOException
{
response.setContentType("text/html;charset=UTF-8");
        response.setHeader("refresh","1");
        PrintWriter out = response.getWriter();
        try {
            
            
            
            out.println(new java.util.Date());
            
           
        } finally { 
            out.close();
        }
}
public void doPost(HttpServletRequest req,HttpServletResponse response) throws ServletException,IOException
{
	doGet(req,response);
}
}